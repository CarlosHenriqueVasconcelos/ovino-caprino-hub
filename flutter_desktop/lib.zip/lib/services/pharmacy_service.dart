import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/pharmacy_stock.dart';
import '../models/pharmacy_stock_movement.dart';
import '../data/pharmacy_repository.dart';

class PharmacyService extends ChangeNotifier {
  final PharmacyRepository _repository;
  static const _uuid = Uuid();

  PharmacyService(this._repository);

  // Listar medicamentos em estoque
  Future<List<PharmacyStock>> getPharmacyStock() async {
    try {
      return await _repository.getAllStock();
    } catch (e) {
      debugPrint('Erro ao buscar estoque da farmácia: $e');
      return [];
    }
  }

  // Buscar medicamento por ID
  Future<PharmacyStock?> getStockById(String id) async {
    try {
      return await _repository.getStockById(id);
    } catch (e) {
      debugPrint('Erro ao buscar medicamento: $e');
      return null;
    }
  }

  // Criar medicamento
  Future<void> createMedication(PharmacyStock stock) async {
    try {
      // Insere no SQLite local
      await _repository.insertStock(stock);

      // Registra a movimentação inicial
      if (stock.totalQuantity > 0) {
        await recordMovement(
          PharmacyStockMovement(
            id: _uuid.v4(),
            pharmacyStockId: stock.id,
            movementType: 'entrada',
            quantity: stock.totalQuantity,
            reason: 'Cadastro inicial',
            createdAt: DateTime.now(),
          ),
        );
      }

      // Nota: Sincronização com Supabase é feita apenas via backup manual
    } catch (e) {
      debugPrint('Erro ao criar medicamento: $e');
      rethrow;
    }
  }

  // Atualizar medicamento
  Future<void> updateMedication(String id, PharmacyStock stock) async {
    try {
      await _repository.updateStock(stock);

      // Nota: Sincronização com Supabase é feita apenas via backup manual
    } catch (e) {
      debugPrint('Erro ao atualizar medicamento: $e');
      rethrow;
    }
  }

  // Deletar medicamento
  Future<void> deleteMedication(String id) async {
    try {
      // Repository já cuida da lógica de deleção
      await _repository.deleteStock(id);

      // Nota: Sincronização com Supabase é feita apenas via backup manual
    } catch (e) {
      debugPrint('Erro ao deletar medicamento: $e');
      rethrow;
    }
  }

  // Registrar movimentação
  Future<void> recordMovement(PharmacyStockMovement movement) async {
    try {
      await _repository.recordMovement(movement);

      // Nota: Sincronização com Supabase é feita apenas via backup manual
    } catch (e) {
      debugPrint('Erro ao registrar movimentação: $e');
      rethrow;
    }
  }

  // Buscar histórico de movimentações
  Future<List<PharmacyStockMovement>> getMovements(String stockId) async {
    try {
      return await _repository.getMovementsByStockId(stockId);
    } catch (e) {
      debugPrint('Erro ao buscar movimentações: $e');
      return [];
    }
  }

  // Verificar estoque baixo
  Future<List<PharmacyStock>> getLowStockItems() async {
    try {
      return await _repository.getLowStockItems();
    } catch (e) {
      debugPrint('Erro ao buscar itens com estoque baixo: $e');
      return [];
    }
  }

  // Verificar medicamentos próximos ao vencimento
  Future<List<PharmacyStock>> getExpiringItems(int daysThreshold) async {
    try {
      return await _repository.getExpiringItems(daysThreshold);
    } catch (e) {
      debugPrint('Erro ao buscar itens vencendo: $e');
      return [];
    }
  }

  // Deduzir do estoque (ao aplicar medicação)
  Future<void> deductFromStock(
      String stockId, double quantity, String? medicationId,
      {bool isAmpoule = false}) async {
    try {
      final stock = await getStockById(stockId);
      if (stock == null) {
        throw Exception('Medicamento não encontrado');
      }

      final unit = stock.unitOfMeasure.toLowerCase();

      // Determinar qual lógica usar baseado na unidade de medida
      final useVolumeLogic = (unit == 'ml' || unit == 'mg' || unit == 'g') &&
          stock.quantityPerUnit != null &&
          stock.quantityPerUnit! > 0;

      if (medicationId == null) {
        // Remoção manual - sempre trabalhar com unidades (ampolas/frascos/comprimidos)
        final newQuantity = stock.totalQuantity - quantity;
        if (newQuantity < 0) {
          throw Exception('Quantidade insuficiente em estoque');
        }

        final updated = stock.copyWith(
          totalQuantity: newQuantity,
          updatedAt: DateTime.now(),
        );
        await updateMedication(stockId, updated);

        await recordMovement(
          PharmacyStockMovement(
            id: _uuid.v4(),
            pharmacyStockId: stockId,
            medicationId: null,
            movementType: 'saida',
            quantity: quantity,
            reason: 'Remoção manual',
            createdAt: DateTime.now(),
          ),
        );
      } else if (useVolumeLogic) {
        // Aplicação com ml/mg/g - usar lógica de recipiente com volume
        await _handleVolumeDeduction(stock, quantity, medicationId);
      } else {
        // Aplicação com "Unidade" - descontar diretamente da quantidade total
        final newQuantity = stock.totalQuantity - quantity;
        if (newQuantity < 0) {
          throw Exception('Quantidade insuficiente em estoque');
        }

        final updated = stock.copyWith(
          totalQuantity: newQuantity,
          updatedAt: DateTime.now(),
        );
        await updateMedication(stockId, updated);

        await recordMovement(
          PharmacyStockMovement(
            id: _uuid.v4(),
            pharmacyStockId: stockId,
            medicationId: medicationId,
            movementType: 'saida',
            quantity: quantity,
            reason:
                'Aplicação de medicamento (${quantity.toStringAsFixed(1)} unidade${quantity > 1 ? 's' : ''})',
            createdAt: DateTime.now(),
          ),
        );
      }
    } catch (e) {
      debugPrint('Erro ao deduzir do estoque: $e');
      rethrow;
    }
  }

  // Lógica de desconto por volume (ml/mg/g) com recipientes parciais
  Future<void> _handleVolumeDeduction(
      PharmacyStock stock, double quantityUsed, String? medicationId) async {
    final type = stock.medicationType.toLowerCase();
    String container;
    if (type == 'frasco') {
      container = 'Frasco';
    } else if (type == 'ampola') {
      container = 'Ampola';
    } else if (type == 'spray') {
      container = 'Spray';
    } else if (type == 'pomada') {
      container = 'Pomada';
    } else if (type == 'pó') {
      container = 'Embalagem';
    } else {
      container = 'Recipiente';
    }

    final unitSize = stock.quantityPerUnit!;
    final unit = stock.unitOfMeasure;

    // Validar estoque total disponível antes de aplicar
    final totalAvailable =
        (stock.totalQuantity * unitSize) + stock.openedQuantity;
    if (quantityUsed > totalAvailable) {
      throw Exception(
          'Quantidade insuficiente em estoque. Disponível: ${totalAvailable.toStringAsFixed(2)} $unit');
    }

    // Primeiro verifica se há frasco aberto
    if (stock.openedQuantity > 0) {
      if (quantityUsed <= stock.openedQuantity) {
        // Usa apenas do frasco aberto
        final newOpenedQty = stock.openedQuantity - quantityUsed;
        final updated = stock.copyWith(
          openedQuantity: newOpenedQty,
          isOpened: newOpenedQty > 0,
          updatedAt: DateTime.now(),
        );
        await updateMedication(stock.id, updated);

        await recordMovement(
          PharmacyStockMovement(
            id: _uuid.v4(),
            pharmacyStockId: stock.id,
            medicationId: medicationId,
            movementType: 'saida',
            quantity: quantityUsed,
            reason:
                'Aplicação de medicamento (${quantityUsed.toStringAsFixed(2)} $unit do $container aberto)',
            createdAt: DateTime.now(),
          ),
        );
        return;
      } else {
        // Usa todo o frasco aberto e precisa de mais
        final remaining = quantityUsed - stock.openedQuantity;
        final frascosFechados = (remaining / unitSize).ceil();

        if (stock.totalQuantity < frascosFechados) {
          throw Exception('Quantidade insuficiente em estoque');
        }

        final newOpenedQty = (frascosFechados * unitSize) - remaining;
        final updated = stock.copyWith(
          totalQuantity: stock.totalQuantity - frascosFechados,
          openedQuantity: newOpenedQty,
          isOpened: newOpenedQty > 0,
          updatedAt: DateTime.now(),
        );
        await updateMedication(stock.id, updated);

        await recordMovement(
          PharmacyStockMovement(
            id: _uuid.v4(),
            pharmacyStockId: stock.id,
            medicationId: medicationId,
            movementType: 'saida',
            quantity: quantityUsed,
            reason:
                'Aplicação de medicamento (${stock.openedQuantity.toStringAsFixed(2)} $unit do aberto + ${remaining.toStringAsFixed(2)} $unit de $frascosFechados novo${frascosFechados > 1 ? 's' : ''})',
            createdAt: DateTime.now(),
          ),
        );
        return;
      }
    }

    // Não há frasco aberto
    if (quantityUsed == unitSize) {
      // Usa um frasco completo
      final newQuantity = stock.totalQuantity - 1;
      if (newQuantity < 0) {
        throw Exception('Quantidade insuficiente em estoque');
      }

      final updated = stock.copyWith(
        totalQuantity: newQuantity,
        updatedAt: DateTime.now(),
      );
      await updateMedication(stock.id, updated);

      await recordMovement(
        PharmacyStockMovement(
          id: _uuid.v4(),
          pharmacyStockId: stock.id,
          medicationId: medicationId,
          movementType: 'saida',
          quantity: 1,
          reason: 'Aplicação de medicamento ($container completo)',
          createdAt: DateTime.now(),
        ),
      );
    } else {
      // Uso parcial - abre um novo frasco
      final remaining = unitSize - quantityUsed;
      if (remaining < 0) {
        throw Exception(
            'Quantidade usada maior que a capacidade do $container');
      }

      if (stock.totalQuantity < 1) {
        throw Exception('Quantidade insuficiente em estoque');
      }

      final updated = stock.copyWith(
        totalQuantity: stock.totalQuantity - 1,
        openedQuantity: remaining,
        isOpened: true,
        updatedAt: DateTime.now(),
      );
      await updateMedication(stock.id, updated);

      await recordMovement(
        PharmacyStockMovement(
          id: _uuid.v4(),
          pharmacyStockId: stock.id,
          medicationId: medicationId,
          movementType: 'saida',
          quantity: quantityUsed,
          reason:
              'Aplicação de medicamento (${quantityUsed.toStringAsFixed(2)} $unit usados, ${remaining.toStringAsFixed(2)} $unit restantes no $container aberto)',
          createdAt: DateTime.now(),
        ),
      );
    }
  }

  // Adicionar ao estoque (ao cancelar medicação ou comprar)
  Future<void> addToStock(String stockId, double quantity,
      {String? reason}) async {
    try {
      final stock = await getStockById(stockId);
      if (stock == null) {
        throw Exception('Medicamento não encontrado');
      }

      final newQuantity = stock.totalQuantity + quantity;
      final updated = stock.copyWith(
        totalQuantity: newQuantity,
        updatedAt: DateTime.now(),
      );
      await updateMedication(stockId, updated);

      // Registrar movimentação
      await recordMovement(
        PharmacyStockMovement(
          id: _uuid.v4(),
          pharmacyStockId: stockId,
          movementType: 'entrada',
          quantity: quantity,
          reason: reason ?? 'Entrada manual',
          createdAt: DateTime.now(),
        ),
      );
    } catch (e) {
      debugPrint('Erro ao adicionar ao estoque: $e');
      rethrow;
    }
  }
}
