import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/pharmacy_stock.dart';
import '../services/pharmacy_service.dart';
import 'pharmacy_stock_details.dart';
import 'pharmacy_stock_form.dart';
import 'pharmacy/pharmacy_actions_bar.dart';
import 'pharmacy/pharmacy_enums.dart';
import 'pharmacy/pharmacy_filters_bar.dart';
import 'pharmacy/pharmacy_movement_dialogs.dart';
import 'pharmacy/pharmacy_stock_list_section.dart';

class PharmacyManagementScreen extends StatefulWidget {
  const PharmacyManagementScreen({super.key});

  @override
  State<PharmacyManagementScreen> createState() =>
      _PharmacyManagementScreenState();
}

class _PharmacyManagementScreenState extends State<PharmacyManagementScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<PharmacyStock> _stock = [];
  bool _isLoading = true;
  String _searchTerm = '';
  String _selectedCategory = 'Todos';
  StockStatusFilter _statusFilter = StockStatusFilter.all;
  int _currentPage = 0;
  int _itemsPerPage = 20;

  @override
  void initState() {
    super.initState();
    _loadStock();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadStock() async {
    setState(() => _isLoading = true);
    try {
      final service = context.read<PharmacyService>();
      final data = await service.getPharmacyStock();
      if (!mounted) return;
      setState(() {
        _stock = data;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao carregar estoque: $e')),
      );
    }
  }

  List<String> get _categories {
    final set = <String>{};
    for (final item in _stock) {
      if (item.medicationType.isNotEmpty) set.add(item.medicationType);
    }
    final list = set.toList()..sort();
    return ['Todos', ...list];
  }

  List<PharmacyStock> _filteredStock() {
    var result = _stock.toList();
    if (_searchTerm.isNotEmpty) {
      final term = _searchTerm.toLowerCase();
      result = result
          .where((s) => s.medicationName.toLowerCase().contains(term))
          .toList();
    }
    if (_selectedCategory != 'Todos') {
      result = result
          .where((s) => s.medicationType == _selectedCategory)
          .toList();
    }
    result = result.where((item) {
      switch (_statusFilter) {
        case StockStatusFilter.lowStock:
          return item.isLowStock && !item.isExpired;
        case StockStatusFilter.expiring:
          return item.isExpiringSoon && !item.isExpired;
        case StockStatusFilter.expired:
          return item.isExpired;
        case StockStatusFilter.all:
        default:
          return true;
      }
    }).toList();

    result.sort((a, b) {
      final expA = a.expirationDate ?? DateTime(2100);
      final expB = b.expirationDate ?? DateTime(2100);
      return expA.compareTo(expB);
    });
    return result;
  }

  List<PharmacyStock> _paginatedStock(List<PharmacyStock> stock) {
    if (stock.isEmpty) return const [];
    final start = (_currentPage * _itemsPerPage).clamp(0, stock.length);
    final end = (start + _itemsPerPage).clamp(0, stock.length);
    return stock.sublist(start.toInt(), end.toInt());
  }

  PharmacySummary _buildSummary(List<PharmacyStock> stock) {
    int low = 0;
    int expiring = 0;
    int expired = 0;
    double totalUnits = 0;

    for (final item in stock) {
      if (item.isLowStock) low++;
      if (item.isExpiringSoon) expiring++;
      if (item.isExpired) expired++;
      totalUnits += item.totalQuantity;
    }

    return PharmacySummary(
      totalItems: stock.length,
      lowStock: low,
      expiring: expiring,
      expired: expired,
      totalUnits: totalUnits,
    );
  }

  Future<void> _openStockForm({PharmacyStock? stock}) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => PharmacyStockForm(stock: stock),
    );
    if (!mounted) return;
    if (result == true) _loadStock();
  }

  Future<void> _openDetails(PharmacyStock stock) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => PharmacyStockDetails(stock: stock),
    );
    if (!mounted) return;
    if (result == true) _loadStock();
  }

  Future<void> _registerMovement(String type) async {
    final stock = await showPharmacyStockPickerDialog(context, _stock);
    if (stock == null || !mounted) return;

    final movement = await showPharmacyMovementDialog(
      context,
      stock: stock,
      movementType: type,
    );
    if (movement == null || !mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    final service = context.read<PharmacyService>();

    try {
      if (type == 'entrada') {
        await service.addToStock(
          stock.id,
          movement.quantity,
          reason: movement.reason,
        );
      } else {
        await service.deductFromStock(
          stock.id,
          movement.quantity,
          null,
          isAmpoule: false,
        );
      }
      await _loadStock();
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('Erro: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredStock();
    final paginated = _paginatedStock(filtered);
    final summary = _buildSummary(_stock);
    final totalPages =
        (filtered.length / _itemsPerPage).ceil().clamp(1, 9999);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PharmacyHeader(
                onRefresh: _loadStock,
                onNew: () => _openStockForm(),
              ),
              const SizedBox(height: 12),
              PharmacyActionsBar(
                onNewMedication: _openStockForm,
                onRegisterEntry: () => _registerMovement('entrada'),
                onRegisterExit: () => _registerMovement('saida'),
                onExport: () {},
              ),
              const SizedBox(height: 12),
              PharmacyFiltersBar(
                searchController: _searchController,
                onSearchChanged: (value) {
                  setState(() {
                    _searchTerm = value.toLowerCase();
                    _currentPage = 0;
                  });
                },
                onClearSearch: () {
                  setState(() {
                    _searchController.clear();
                    _searchTerm = '';
                    _currentPage = 0;
                  });
                },
                categories: _categories,
                selectedCategory: _selectedCategory,
                onCategoryChanged: (value) {
                  setState(() {
                    _selectedCategory = value;
                    _currentPage = 0;
                  });
                },
                statusFilter: _statusFilter,
                onStatusChanged: (value) {
                  setState(() {
                    _statusFilter = value;
                    _currentPage = 0;
                  });
                },
              ),
              const SizedBox(height: 16),
              PharmacySummaryCardsRow(summary: summary),
              const SizedBox(height: 16),
              PharmacyLowStockSection(
                items: filtered
                    .where((item) => item.isLowStock && !item.isExpired)
                    .take(4)
                    .toList(),
                onView: _openDetails,
              ),
              const SizedBox(height: 16),
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : PharmacyStockListSection(
                        rows: paginated
                            .map((stock) => PharmacyStockRow.fromStock(stock))
                            .toList(),
                        onView: _openDetails,
                        onEdit: _openStockForm,
                      ),
              ),
              const SizedBox(height: 12),
              if (!_isLoading)
                PharmacyPaginationBar(
                  currentPage: _currentPage,
                  totalPages: totalPages,
                  itemsPerPage: _itemsPerPage,
                  onPageChanged: (value) {
                    setState(() => _currentPage = value);
                  },
                  onItemsPerPageChanged: (value) {
                    setState(() {
                      _itemsPerPage = value;
                      _currentPage = 0;
                    });
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
class PharmacyHeader extends StatelessWidget {
  const PharmacyHeader({
    super.key,
    required this.onRefresh,
    required this.onNew,
  });

  final VoidCallback onRefresh;
  final VoidCallback onNew;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Icon(Icons.local_pharmacy, color: theme.colorScheme.primary),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            'Gestão da Farmácia',
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        OutlinedButton.icon(
          onPressed: onRefresh,
          icon: const Icon(Icons.refresh),
          label: const Text('Atualizar'),
        ),
        const SizedBox(width: 8),
        FilledButton.icon(
          onPressed: onNew,
          icon: const Icon(Icons.add),
          label: const Text('Novo'),
        ),
      ],
    );
  }
}

class PharmacySummaryCardsRow extends StatelessWidget {
  const PharmacySummaryCardsRow({super.key, required this.summary});

  final PharmacySummary summary;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        _SummaryCard(
          icon: Icons.inventory,
          color: Colors.teal,
          title: 'Medicamentos',
          value: summary.totalItems.toString(),
        ),
        _SummaryCard(
          icon: Icons.warning_rounded,
          color: Colors.amber,
          title: 'Estoque baixo',
          value: summary.lowStock.toString(),
        ),
        _SummaryCard(
          icon: Icons.schedule,
          color: Colors.orange,
          title: 'Vencendo / Vencidos',
          value: '${summary.expiring}/${summary.expired}',
        ),
        _SummaryCard(
          icon: Icons.scale,
          color: Colors.blueGrey,
          title: 'Unidades em estoque',
          value: summary.totalUnits.toStringAsFixed(0),
        ),
      ],
    );
  }
}

class PharmacyLowStockSection extends StatelessWidget {
  const PharmacyLowStockSection({
    super.key,
    required this.items,
    required this.onView,
  });

  final List<PharmacyStock> items;
  final ValueChanged<PharmacyStock> onView;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Itens em Baixo Estoque',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Column(
              children: items.map((item) {
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(item.medicationName),
                  subtitle: Text('${item.totalQuantity.toStringAsFixed(0)} ${item.unitOfMeasure}'),
                  trailing: TextButton(
                    onPressed: () => onView(item),
                    child: const Text('Detalhes'),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class PharmacyPaginationBar extends StatelessWidget {
  const PharmacyPaginationBar({
    super.key,
    required this.currentPage,
    required this.totalPages,
    required this.itemsPerPage,
    required this.onPageChanged,
    required this.onItemsPerPageChanged,
  });

  final int currentPage;
  final int totalPages;
  final int itemsPerPage;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<int> onItemsPerPageChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            IconButton(
              icon: const Icon(Icons.chevron_left),
              onPressed:
                  currentPage > 0 ? () => onPageChanged(currentPage - 1) : null,
            ),
            Text('Página ${currentPage + 1} de $totalPages'),
            IconButton(
              icon: const Icon(Icons.chevron_right),
              onPressed: currentPage < totalPages - 1
                  ? () => onPageChanged(currentPage + 1)
                  : null,
            ),
          ],
        ),
        DropdownButton<int>(
          value: itemsPerPage,
          items: const [10, 20, 50]
              .map((e) => DropdownMenuItem(value: e, child: Text('$e por página')))
              .toList(),
          onChanged: (value) {
            if (value != null) onItemsPerPageChanged(value);
          },
        ),
      ],
    );
  }
}

class PharmacySummary {
  PharmacySummary({
    required this.totalItems,
    required this.lowStock,
    required this.expiring,
    required this.expired,
    required this.totalUnits,
  });

  final int totalItems;
  final int lowStock;
  final int expiring;
  final int expired;
  final double totalUnits;
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.value,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.bodySmall),
                Text(
                  value,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
