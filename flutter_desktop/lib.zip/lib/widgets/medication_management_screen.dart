import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/medication_service.dart';
import '../services/pharmacy_service.dart';
import '../services/vaccination_service.dart';
import '../utils/animal_record_display.dart';
import 'medication/add_medication_dialog.dart';
import 'medication/medication_details_dialog.dart';
import 'medication/medication_actions_bar.dart';
import 'medication/medication_filters_bar.dart';
import 'medication/medication_list_section.dart';
import 'medication/medication_tabs.dart';

enum MedicationTabType { overdue, scheduled, completed, cancelled, vaccinations }

enum MedicationStatusFilter {
  overdue,
  scheduled,
  completed,
  cancelled,
  vaccinations,
}

enum VaccinationStatusFilter { overdue, scheduled, applied, cancelled }

class MedicationManagementScreen extends StatefulWidget {
  const MedicationManagementScreen({super.key});

  @override
  State<MedicationManagementScreen> createState() =>
      _MedicationManagementScreenState();
}

class _MedicationManagementScreenState extends State<MedicationManagementScreen>
    with SingleTickerProviderStateMixin {
  Map<String, List<Map<String, dynamic>>> _vaccinationGroups = {
    'Atrasadas': [],
    'Agendadas': [],
    'Aplicadas': [],
    'Canceladas': [],
  };
  Map<String, List<Map<String, dynamic>>> _medicationGroups = {
    'Atrasados': [],
    'Agendados': [],
    'Aplicados': [],
    'Cancelados': [],
  };

  late final TabController _tabController;
  bool _isLoading = true;
  String? _errorMessage;

  String _searchTerm = '';
  String? _selectedSpecies;
  String? _selectedCategory;
  DateTimeRange? _selectedDateRange;
  MedicationStatusFilter _statusFilter = MedicationStatusFilter.overdue;
  VaccinationStatusFilter _vaccinationFilter = VaccinationStatusFilter.overdue;

  final Map<String, MedicationTabType> _selectedItems = {};
  List<String> _speciesOptions = [];
  List<String> _categoryOptions = [];
  Timer? _searchDebounce;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: MedicationTabType.values.length,
      vsync: this,
    );
    _tabController.addListener(_handleTabChanged);
    _loadData();
  }

  void _handleTabChanged() {
    if (_tabController.indexIsChanging) return;
    setState(() {
      _statusFilter = MedicationStatusFilter.values[_tabController.index];
    });
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChanged);
    _tabController.dispose();
    _searchDebounce?.cancel();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final vaccinationService =
          Provider.of<VaccinationService>(context, listen: false);
      final medicationService =
          Provider.of<MedicationService>(context, listen: false);
      final medOptions = MedicationQueryOptions(
        species: _selectedSpecies,
        category: _selectedCategory,
        searchTerm: _searchTerm.isEmpty ? null : _searchTerm,
        startDate: _selectedDateRange?.start,
        endDate: _selectedDateRange?.end,
      );
      final vacOptions = VaccinationQueryOptions(
        species: _selectedSpecies,
        category: _selectedCategory,
        searchTerm: _searchTerm.isEmpty ? null : _searchTerm,
        startDate: _selectedDateRange?.start,
        endDate: _selectedDateRange?.end,
      );

      final results = await Future.wait<List<Map<String, dynamic>>>([
        vaccinationService.getOverdueVaccinationsWithAnimalInfo(
          options: vacOptions,
        ),
        vaccinationService.getScheduledVaccinationsWithAnimalInfo(
          options: vacOptions,
        ),
        vaccinationService.getAppliedVaccinationsWithAnimalInfo(
          options: vacOptions,
        ),
        vaccinationService.getCancelledVaccinationsWithAnimalInfo(
          options: vacOptions,
        ),
        medicationService.getOverdueMedicationsWithAnimalInfo(
          options: medOptions,
        ),
        medicationService.getScheduledMedicationsWithAnimalInfo(
          options: medOptions,
        ),
        medicationService.getAppliedMedicationsWithAnimalInfo(
          options: medOptions,
        ),
        medicationService.getCancelledMedicationsWithAnimalInfo(
          options: medOptions,
        ),
      ]);

      if (!mounted) return;

      setState(() {
        _vaccinationGroups = {
          'Atrasadas': List<Map<String, dynamic>>.from(results[0]),
          'Agendadas': List<Map<String, dynamic>>.from(results[1]),
          'Aplicadas': List<Map<String, dynamic>>.from(results[2]),
          'Canceladas': List<Map<String, dynamic>>.from(results[3]),
        };
        _medicationGroups = {
          'Atrasados': List<Map<String, dynamic>>.from(results[4]),
          'Agendados': List<Map<String, dynamic>>.from(results[5]),
          'Aplicados': List<Map<String, dynamic>>.from(results[6]),
          'Cancelados': List<Map<String, dynamic>>.from(results[7]),
        };
        _speciesOptions = _computeSpeciesOptions();
        _categoryOptions = _computeCategoryOptions();
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _errorMessage = 'Erro ao carregar dados. Tente novamente.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final medicationTabs = _buildMedicationTabConfigs();
    final vaccinationItems =
        _vaccinationGroups[_vaccinationKeyForFilter(_vaccinationFilter)] ??
            const [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Vacinações e Medicamentos'),
      ),
      body: Column(
        children: [
          MedicationFiltersBar(
            statusFilter: _statusFilter,
            searchTerm: _searchTerm,
            selectedSpecies: _selectedSpecies,
            selectedCategory: _selectedCategory,
            dateRange: _selectedDateRange,
            speciesOptions: _speciesOptions,
            categoryOptions: _categoryOptions,
            onStatusChanged: _onStatusFilterChanged,
            onSearchChanged: _handleSearchChanged,
            onSpeciesChanged: (value) {
              setState(() => _selectedSpecies = value);
              _loadData();
            },
            onCategoryChanged: (value) {
              setState(() => _selectedCategory = value);
              _loadData();
            },
            onSelectDateRange: () {
              _pickDateRange().then((_) {
                if (_selectedDateRange != null) {
                  _loadData();
                }
              });
            },
            onClearDateRange: () {
              setState(() => _selectedDateRange = null);
              _loadData();
            },
          ),
          MedicationActionsBar(
            onAddMedication: () => showMedicationFormDialog(
              context,
              onSaved: _loadData,
              initialType: 'Medicação',
            ),
            onAddVaccination: () => showMedicationFormDialog(
              context,
              onSaved: _loadData,
              initialType: 'Vacinação',
            ),
            onExport: _exportData,
            onViewHistory: _viewHistory,
            selectionCount: _selectedItems.length,
            onClearSelection:
                _selectedItems.isEmpty ? null : _clearSelection,
          ),
          Expanded(
            child: MedicationTabs(
              controller: _tabController,
              configs: medicationTabs,
              vaccinationItems: vaccinationItems,
              vaccinationFilter: _vaccinationFilter,
              onVaccinationFilterChanged: (filter) {
                setState(() => _vaccinationFilter = filter);
              },
              onNewVaccination: () => showMedicationFormDialog(
                context,
                onSaved: _loadData,
                initialType: 'Vacinação',
              ),
              onRegisterVaccinationDose: _registerVaccinationDose,
              onRefreshVaccinations: _loadData,
              isLoading: _isLoading,
              errorMessage: _errorMessage,
              selectedItems: _selectedItems,
              onSelectionChanged: _handleSelectionChange,
              onShowDetails: (data, isVaccination) =>
                  showRecordDetailsDialog(
                    context,
                    data: data,
                    isVaccination: isVaccination,
                  ),
              onShowOptions: (record, isVaccination) {
                if (isVaccination) {
                  _showVaccinationOptions(record);
                } else {
                  _showMedicationOptions(record);
                }
              },
              onApply: (id, isVaccination) =>
                  _markAsApplied(id, isVaccination: isVaccination),
              onCancel: (id, isVaccination) =>
                  _cancelItem(id, isVaccination: isVaccination),
              formatDate: _formatDate,
            ),
          ),
        ],
      ),
    );
  }

  void _onStatusFilterChanged(MedicationStatusFilter filter) {
    setState(() {
      _statusFilter = filter;
      _tabController.animateTo(filter.index);
    });
  }

  void _handleSelectionChange(
    String id,
    MedicationTabType type,
    bool isSelected,
  ) {
    setState(() {
      if (isSelected) {
        _selectedItems[id] = type;
      } else {
        _selectedItems.remove(id);
      }
    });
  }

  void _clearSelection() {
    setState(() => _selectedItems.clear());
  }

  Future<void> _pickDateRange() async {
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2022),
      lastDate: DateTime(2100),
      initialDateRange: _selectedDateRange,
    );
    if (range != null) {
      setState(() => _selectedDateRange = range);
    }
  }

  List<MedicationTabConfig> _buildMedicationTabConfigs() {
    return [
      MedicationTabConfig(
        type: MedicationTabType.overdue,
        title: 'Atrasados',
        icon: Icons.warning_amber_outlined,
        items: _medicationGroups['Atrasados'] ?? const [],
        emptyMessage: 'Nenhum medicamento atrasado',
        allowActions: true,
        isVaccination: false,
      ),
      MedicationTabConfig(
        type: MedicationTabType.scheduled,
        title: 'Agendados',
        icon: Icons.schedule_outlined,
        items: _medicationGroups['Agendados'] ?? const [],
        emptyMessage: 'Nenhum medicamento agendado',
        allowActions: true,
        isVaccination: false,
      ),
      MedicationTabConfig(
        type: MedicationTabType.completed,
        title: 'Aplicados',
        icon: Icons.check_circle_outline,
        items: _medicationGroups['Aplicados'] ?? const [],
        emptyMessage: 'Nenhum medicamento aplicado',
        allowActions: false,
        isVaccination: false,
      ),
      MedicationTabConfig(
        type: MedicationTabType.cancelled,
        title: 'Cancelados',
        icon: Icons.cancel_outlined,
        items: _medicationGroups['Cancelados'] ?? const [],
        emptyMessage: 'Nenhum medicamento cancelado',
        allowActions: false,
        isVaccination: false,
      ),
    ];
  }

  String _vaccinationKeyForFilter(VaccinationStatusFilter filter) {
    switch (filter) {
      case VaccinationStatusFilter.overdue:
        return 'Atrasadas';
      case VaccinationStatusFilter.scheduled:
        return 'Agendadas';
      case VaccinationStatusFilter.applied:
        return 'Aplicadas';
      case VaccinationStatusFilter.cancelled:
        return 'Canceladas';
    }
  }

  List<String> _computeSpeciesOptions() {
    final values = <String>{};
    for (final record in _allRecords()) {
      final value =
          _resolveField(record, const ['species', 'animal_species']);
      if (value != null) values.add(value);
    }
    final result = values.toList()..sort();
    return result;
  }

  List<String> _computeCategoryOptions() {
    final values = <String>{};
    for (final record in _allRecords()) {
      final value =
          _resolveField(record, const ['category', 'animal_category']);
      if (value != null) values.add(value);
    }
    final result = values.toList()..sort();
    return result;
  }

  String? _resolveField(Map<String, dynamic> record, List<String> keys) {
    for (final key in keys) {
      final value = record[key];
      if (value != null && value.toString().isNotEmpty) {
        return value.toString();
      }
    }
    return null;
  }

  Iterable<Map<String, dynamic>> _allRecords() sync* {
    for (final list in _medicationGroups.values) {
      yield* list;
    }
    for (final list in _vaccinationGroups.values) {
      yield* list;
    }
  }

  void _handleSearchChanged(String value) {
    _searchDebounce?.cancel();
    setState(() => _searchTerm = value.trim());
    _searchDebounce = Timer(
      const Duration(milliseconds: 350),
      () => _loadData(),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'N/A';
    try {
      final dt = DateTime.parse(date.toString());
      return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
    } catch (_) {
      return date.toString();
    }
  }

  void _exportData() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Exportação ainda não implementada.'),
      ),
    );
  }

  void _viewHistory() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Histórico ainda não implementado.'),
      ),
    );
  }

  void _registerVaccinationDose() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Registro de dose ainda não implementado.'),
      ),
    );
  }

  Future<void> _markAsApplied(String id, {required bool isVaccination}) async {
    final vaccinationService =
        Provider.of<VaccinationService>(context, listen: false);
    final medicationService =
        Provider.of<MedicationService>(context, listen: false);
    final pharmacyService =
        Provider.of<PharmacyService>(context, listen: false);

    try {
      final now = DateTime.now();
      final today = now.toIso8601String().split('T')[0];

      if (isVaccination) {
        await vaccinationService.updateVaccination(id, {
          'status': 'Aplicada',
          'applied_date': today,
        });
      } else {
        final medication = await medicationService.getMedicationById(id);

        if (medication != null) {
          final pharmacyStockId = medication['pharmacy_stock_id'] as String?;
          final quantityUsed =
              (medication['quantity_used'] as num?)?.toDouble();

          await medicationService.updateMedication(id, {
            'status': 'Aplicado',
            'applied_date': today,
          });

          if (pharmacyStockId != null &&
              quantityUsed != null &&
              quantityUsed > 0) {
            await pharmacyService.deductFromStock(
              pharmacyStockId,
              quantityUsed,
              id,
            );
          }
        }
      }

      await _loadData();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isVaccination
                ? 'Vacinação aplicada com sucesso!'
                : 'Medicamento aplicado e estoque atualizado!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao marcar como aplicado: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _cancelItem(String id, {required bool isVaccination}) async {
    final vaccinationService =
        Provider.of<VaccinationService>(context, listen: false);
    final medicationService =
        Provider.of<MedicationService>(context, listen: false);

    try {
      if (isVaccination) {
        await vaccinationService.updateVaccination(id, {
          'status': 'Cancelada',
        });
      } else {
        await medicationService.updateMedication(id, {
          'status': 'Cancelado',
        });
      }

      await _loadData();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(isVaccination
                ? 'Vacinação cancelada'
                : 'Medicamento cancelado'),
            backgroundColor: Colors.orange,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao cancelar: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showVaccinationOptions(Map<String, dynamic> vaccination) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.visibility),
            title: const Text('Ver Detalhes'),
            onTap: () {
              Navigator.pop(context);
              showRecordDetailsDialog(
                context,
                data: vaccination,
                isVaccination: true,
              );
            },
          ),
          if (vaccination['status'] == 'Agendada') ...[
            ListTile(
              leading: const Icon(Icons.check, color: Colors.green),
              title: const Text('Marcar como aplicada'),
              onTap: () {
                Navigator.pop(context);
                _markAsApplied(vaccination['id'], isVaccination: true);
              },
            ),
            ListTile(
              leading: const Icon(Icons.cancel, color: Colors.red),
              title: const Text('Cancelar vacinação'),
              onTap: () {
                Navigator.pop(context);
                _cancelItem(vaccination['id'], isVaccination: true);
              },
            ),
          ],
        ],
      ),
    );
  }

  void _showMedicationOptions(Map<String, dynamic> medication) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.visibility),
            title: const Text('Ver Detalhes'),
            onTap: () {
              Navigator.pop(context);
              showRecordDetailsDialog(
                context,
                data: medication,
                isVaccination: false,
              );
            },
          ),
          if (medication['status'] == 'Agendado') ...[
            ListTile(
              leading: const Icon(Icons.check, color: Colors.green),
              title: const Text('Marcar como aplicado'),
              onTap: () {
                Navigator.pop(context);
                _markAsApplied(medication['id'], isVaccination: false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.cancel, color: Colors.red),
              title: const Text('Cancelar medicamento'),
              onTap: () {
                Navigator.pop(context);
                _cancelItem(medication['id'], isVaccination: false);
              },
            ),
          ],
        ],
      ),
    );
  }
}

Future<void> showMedicationFormDialog(
  BuildContext context, {
  required VoidCallback onSaved,
  String initialType = 'Vacinação',
}) {
  return showDialog(
    context: context,
    builder: (context) => AddMedicationDialog(
      onSaved: onSaved,
      initialType: initialType,
    ),
  );
}

Future<void> showRecordDetailsDialog(
  BuildContext context, {
  required Map<String, dynamic> data,
  required bool isVaccination,
}) {
  return showDialog(
    context: context,
    builder: (context) => MedicationDetailsDialog(
      data: data,
      animalLabel: AnimalRecordDisplay.labelFromRecord(data),
      isVaccination: isVaccination,
    ),
  );
}
