import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models/animal.dart';
import '../services/animal_service.dart';
import '../services/weight_service.dart';
import '../utils/animal_record_display.dart';
import 'weight_tracking/weight_tracking_filters_bar.dart';
import 'weight_tracking/weight_tracking_pagination_bar.dart';
import 'weight_tracking/weight_tracking_table.dart';

class LambWeightTracking extends StatefulWidget {
  const LambWeightTracking({super.key});

  @override
  State<LambWeightTracking> createState() => _LambWeightTrackingState();
}

class _LambWeightTrackingState extends State<LambWeightTracking> {
  final TextEditingController _searchController = TextEditingController();

  String _searchTerm = '';
  String _selectedLot = 'Todos';
  String _selectedGender = 'Todos';
  LambAgeFilter _ageFilter = LambAgeFilter.all;
  int _currentPage = 0;
  int _itemsPerPage = 25;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final animalService = context.watch<AnimalService>();
    final weightService = context.read<WeightService>();

    final lambs = _filterLambs(animalService.animals);
    final lots = _availableLots(animalService.animals);
    final summary = LambWeightSummary.fromAnimals(lambs);
    final paginated = _paginatedLambs(lambs);
    final lambRows =
        paginated.map((animal) => LambWeightRow.fromAnimal(animal)).toList();
    final totalPages = (lambs.length / _itemsPerPage).ceil().clamp(1, 9999);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            theme.colorScheme.primary.withOpacity(0.05),
            Colors.transparent,
          ],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _SectionHeader(theme: theme),
            const SizedBox(height: 16),
            WeightTrackingFiltersBar(
              searchController: _searchController,
              searchLabel: 'Pesquisar (nome ou brinco)',
              onSearchChanged: (value) {
                setState(() {
                  _searchTerm = value.toLowerCase();
                  _currentPage = 0;
                });
              },
              onClearSearch: () {
                setState(() {
                  _searchController.clear();
                  _searchTerm = '';
                  _currentPage = 0;
                });
              },
              dropdowns: [
                WeightFilterDropdownConfig(
                  label: 'Lote',
                  options: lots,
                  value: _selectedLot,
                  onChanged: (value) {
                    setState(() {
                      _selectedLot = value;
                      _currentPage = 0;
                    });
                  },
                ),
                WeightFilterDropdownConfig(
                  label: 'Sexo',
                  options: const ['Todos', 'Macho', 'Fêmea'],
                  value: _selectedGender,
                  onChanged: (value) {
                    setState(() {
                      _selectedGender = value;
                      _currentPage = 0;
                    });
                  },
                ),
              ],
              extraFilters: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: LambAgeFilter.values.map((filter) {
                    return ChoiceChip(
                      label: Text(filter.label),
                      selected: _ageFilter == filter,
                      onSelected: (_) {
                        setState(() {
                          _ageFilter = filter;
                          _currentPage = 0;
                        });
                      },
                    );
                  }).toList(),
                ),
              ],
            ),
            const SizedBox(height: 16),
            WeightTrackingSummaryHeader(summary: summary),
            const SizedBox(height: 16),
            Expanded(
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: WeightTrackingTable<LambWeightRow>(
                    items: lambRows,
                    mode: WeightTrackingTableMode.data,
                    columns: const [
                      DataColumn(label: Text('Animal')),
                      DataColumn(label: Text('Idade (dias)')),
                      DataColumn(label: Text('Peso atual (kg)')),
                      DataColumn(label: Text('Ganho total (kg)')),
                      DataColumn(label: Text('Status')),
                      DataColumn(label: Text('Ações')),
                    ],
                    dataRowBuilder: (row) => DataRow(
                      cells: [
                        DataCell(_AnimalCell(animal: row.animal)),
                        DataCell(Text(row.ageInDays.toString())),
                        DataCell(Text(row.latestWeight.toStringAsFixed(1))),
                        DataCell(Text(row.totalGainText)),
                        DataCell(
                          Chip(
                            label: Text(row.status.message),
                            avatar: Icon(
                              row.status.icon,
                              color: row.status.color,
                              size: 16,
                            ),
                            backgroundColor: row.status.color.withOpacity(0.1),
                          ),
                        ),
                        DataCell(
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit),
                                tooltip: 'Editar pesos',
                                onPressed: () async {
                                  await showLambWeightEntryDialog(
                                    context: context,
                                    lamb: row.animal,
                                    weightService: weightService,
                                    animalService: animalService,
                                  );
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.upgrade),
                                tooltip: 'Promover',
                                onPressed: row.ageInDays >= 120
                                    ? () => _promoteToAdult(row.animal)
                                    : null,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    emptyState: const Center(
                      child: Padding(
                        padding: EdgeInsets.all(40),
                        child: Text(
                          'Nenhum borrego encontrado para os filtros atuais.',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            WeightTrackingPaginationBar(
              currentPage: _currentPage,
              totalPages: totalPages,
              itemsPerPage: _itemsPerPage,
              onPageChanged: (page) {
                setState(() => _currentPage = page);
              },
              onItemsPerPageChanged: (value) {
                setState(() {
                  _itemsPerPage = value;
                  _currentPage = 0;
                });
              },
              itemsPerPageOptions: const [10, 25, 50],
            ),
          ],
        ),
      ),
    );
  }

  List<Animal> _filterLambs(List<Animal> animals) {
    var lambs = animals.where((animal) =>
        animal.category.toLowerCase().contains('borrego') ||
        animal.category.toLowerCase().contains('borrega')).toList();

    if (_searchTerm.isNotEmpty) {
      lambs = lambs
          .where((animal) =>
              animal.name.toLowerCase().contains(_searchTerm) ||
              animal.code.toLowerCase().contains(_searchTerm))
          .toList();
    }

    if (_selectedLot != 'Todos') {
      lambs = lambs.where((animal) => animal.lote == _selectedLot).toList();
    }

    if (_selectedGender != 'Todos') {
      lambs = lambs.where((animal) => animal.gender == _selectedGender).toList();
    }

    lambs = lambs.where((animal) {
      switch (_ageFilter) {
        case LambAgeFilter.upTo3Months:
          return _ageInMonths(animal) <= 3;
        case LambAgeFilter.threeToSixMonths:
          final months = _ageInMonths(animal);
          return months > 3 && months <= 6;
        case LambAgeFilter.sixToNineMonths:
          final months = _ageInMonths(animal);
          return months > 6 && months <= 9;
        case LambAgeFilter.nineToTwelveMonths:
          final months = _ageInMonths(animal);
          return months > 9 && months <= 12;
        case LambAgeFilter.all:
        default:
          return true;
      }
    }).toList();

    lambs.sort((a, b) =>
        a.nameColor.toLowerCase().compareTo(b.nameColor.toLowerCase()));
    return lambs;
  }

  List<Animal> _paginatedLambs(List<Animal> lambs) {
    if (lambs.isEmpty) return const [];
    final total = lambs.length;
    final start = (_currentPage * _itemsPerPage).clamp(0, total);
    final end = (start + _itemsPerPage).clamp(0, total);
    final safeStart = start.toInt();
    final safeEnd = end.toInt();
    return lambs.sublist(safeStart, safeEnd);
  }

  int _ageInMonths(Animal animal) {
    final now = DateTime.now();
    final months = (now.year - animal.birthDate.year) * 12 +
        (now.month - animal.birthDate.month);
    return months;
  }

  List<String> _availableLots(List<Animal> animals) {
    final lots = <String>{};
    for (final animal in animals) {
      if ((animal.category).toLowerCase().contains('borrego')) {
        if (animal.lote != null && animal.lote!.isNotEmpty) {
          lots.add(animal.lote!);
        }
      }
    }
    final result = ['Todos', ...lots.toList()..sort()];
    return result;
  }

  Future<void> _promoteToAdult(Animal lamb) async {
    final animalService = context.read<AnimalService>();
    final updated = lamb.copyWith(category: 'Adulto');
    await animalService.updateAnimal(updated);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Borrego promovido para adulto.')),
    );
  }
}

class WeightTrackingSummaryHeader extends StatelessWidget {
  final LambWeightSummary summary;

  const WeightTrackingSummaryHeader({super.key, required this.summary});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        _SummaryCard(
          icon: Icons.monitor_weight,
          color: theme.colorScheme.primary,
          title: 'Peso médio atual',
          value: summary.avgWeightText,
        ),
        _SummaryCard(
          icon: Icons.trending_up,
          color: theme.colorScheme.secondary,
          title: 'Ganho médio diário',
          value: summary.avgDailyGainText,
        ),
        _SummaryCard(
          icon: Icons.pets,
          color: theme.colorScheme.tertiary,
          title: 'Borregos monitorados',
          value: summary.totalLambs.toString(),
        ),
        _SummaryCard(
          icon: Icons.upgrade,
          color: theme.colorScheme.error,
          title: 'Prontos para adulto',
          value: summary.readyForPromotion.toString(),
        ),
      ],
    );
  }
}

Future<void> showLambWeightEntryDialog({
  required BuildContext context,
  required Animal lamb,
  required WeightService weightService,
  required AnimalService animalService,
}) async {
  final messenger = ScaffoldMessenger.of(context);
  final weight120 =
      lamb.weight120Days ?? await _fetchMilestoneWeight(weightService, lamb.id, '120d');
  if (!context.mounted) return;

  final birthWeightController =
      TextEditingController(text: lamb.birthWeight?.toStringAsFixed(1) ?? '');
  final weight30Controller =
      TextEditingController(text: lamb.weight30Days?.toStringAsFixed(1) ?? '');
  final weight60Controller =
      TextEditingController(text: lamb.weight60Days?.toStringAsFixed(1) ?? '');
  final weight90Controller =
      TextEditingController(text: lamb.weight90Days?.toStringAsFixed(1) ?? '');
  final weight120Controller =
      TextEditingController(text: weight120?.toStringAsFixed(1) ?? '');

  await showDialog<void>(
    context: context,
    builder: (dialogContext) {
      return AlertDialog(
        title: Text('Editar Pesos - ${lamb.name}'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _WeightInputField('Peso ao nascer (kg)', birthWeightController),
              const SizedBox(height: 12),
              _WeightInputField('Peso 30 dias (kg)', weight30Controller),
              const SizedBox(height: 12),
              _WeightInputField('Peso 60 dias (kg)', weight60Controller),
              const SizedBox(height: 12),
              _WeightInputField('Peso 90 dias (kg)', weight90Controller),
              const SizedBox(height: 12),
              _WeightInputField('Peso 120 dias (kg)', weight120Controller),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              final birthWeightValue =
                  double.tryParse(birthWeightController.text);
              final weight30Value = double.tryParse(weight30Controller.text);
              final weight60Value = double.tryParse(weight60Controller.text);
              final weight90Value = double.tryParse(weight90Controller.text);
              final weight120Value = double.tryParse(weight120Controller.text);

              final latestWeight = weight120Value ??
                  weight90Value ??
                  weight60Value ??
                  weight30Value ??
                  birthWeightValue ??
                  lamb.weight;

              final updated = lamb.copyWith(
                birthWeight: birthWeightValue,
                weight30Days: weight30Value,
                weight60Days: weight60Value,
                weight90Days: weight90Value,
                weight120Days: weight120Value,
                weight: latestWeight,
              );

              await animalService.updateAnimal(updated);

              if (weight120Value != null) {
                await weightService.addWeight(
                  lamb.id,
                  DateTime.now(),
                  weight120Value,
                  milestone: '120d',
                );
              }

              if (dialogContext.mounted) {
                Navigator.of(dialogContext).pop();
              }
              messenger.showSnackBar(
                const SnackBar(content: Text('Pesos atualizados com sucesso.')),
              );
            },
            child: const Text('Salvar'),
          ),
        ],
      );
    },
  );
}

Future<double?> _fetchMilestoneWeight(
  WeightService weightService,
  String animalId,
  String milestone,
) async {
  final history = await weightService.getWeightHistory(animalId);
  final entry = history.firstWhere(
    (item) => item['milestone']?.toString() == milestone,
    orElse: () => const {},
  );
  final weight = entry['weight'];
  if (weight is num) return weight.toDouble();
  return null;
}

class LambWeightSummary {
  LambWeightSummary({
    required this.totalLambs,
    required this.avgWeight,
    required this.avgDailyGain,
    required this.readyForPromotion,
  });

  final int totalLambs;
  final double avgWeight;
  final double avgDailyGain;
  final int readyForPromotion;

  String get avgWeightText =>
      totalLambs == 0 ? '—' : '${avgWeight.toStringAsFixed(1)} kg';

  String get avgDailyGainText =>
      totalLambs == 0 ? '—' : '${avgDailyGain.toStringAsFixed(2)} kg/dia';

  static LambWeightSummary fromAnimals(List<Animal> animals) {
    if (animals.isEmpty) {
      return LambWeightSummary(
        totalLambs: 0,
        avgWeight: 0,
        avgDailyGain: 0,
        readyForPromotion: 0,
      );
    }

    double latestWeightSum = 0;
    double gainSum = 0;
    int ready = 0;

    for (final animal in animals) {
      final latestWeight = animal.weight120Days ??
          animal.weight90Days ??
          animal.weight60Days ??
          animal.weight30Days ??
          animal.birthWeight ??
          animal.weight;
      latestWeightSum += latestWeight;

      final gain = latestWeight - (animal.birthWeight ?? latestWeight);
      gainSum += gain / (AnimalAgeHelper.ageInDays(animal) + 1);

      if (AnimalAgeHelper.ageInDays(animal) >= 120) {
        ready++;
      }
    }

    return LambWeightSummary(
      totalLambs: animals.length,
      avgWeight: latestWeightSum / animals.length,
      avgDailyGain: gainSum / animals.length,
      readyForPromotion: ready,
    );
  }
}

class LambWeightRow {
  LambWeightRow({
    required this.animal,
    required this.latestWeight,
    required this.ageInDays,
    required this.totalGain,
    required this.status,
  });

  final Animal animal;
  final double latestWeight;
  final int ageInDays;
  final double? totalGain;
  final LambWeightStatus status;

  String get totalGainText =>
      totalGain == null ? '—' : '${totalGain!.toStringAsFixed(1)} kg';

  factory LambWeightRow.fromAnimal(Animal animal) {
    final ageInDays = AnimalAgeHelper.ageInDays(animal);
    final double latestWeight = animal.weight120Days ??
        animal.weight90Days ??
        animal.weight60Days ??
        animal.weight30Days ??
        animal.weight;
    final gain = animal.birthWeight == null
        ? null
        : latestWeight - animal.birthWeight!;

    return LambWeightRow(
      animal: animal,
      latestWeight: latestWeight,
      ageInDays: ageInDays,
      totalGain: gain,
      status: LambWeightStatus.fromAnimal(animal, latestWeight, ageInDays),
    );
  }
}

class LambWeightStatus {
  final String message;
  final Color color;
  final IconData icon;

  LambWeightStatus({
    required this.message,
    required this.color,
    required this.icon,
  });

  factory LambWeightStatus.fromAnimal(
    Animal animal,
    double latestWeight,
    int ageInDays,
  ) {
    if (ageInDays >= 120) {
      return LambWeightStatus(
        message: 'Apto para promoção',
        color: Colors.blueAccent,
        icon: Icons.upgrade,
      );
    }

    final expected = _expectedWeightForAge(ageInDays);
    if (latestWeight >= expected) {
      return LambWeightStatus(
        message: 'Dentro do esperado',
        color: Colors.green,
        icon: Icons.check_circle,
      );
    } else {
      return LambWeightStatus(
        message: 'Atenção ao ganho de peso',
        color: Colors.orange,
        icon: Icons.warning,
      );
    }
  }

  static double _expectedWeightForAge(int ageInDays) {
    if (ageInDays < 30) return 7;
    if (ageInDays < 60) return 12;
    if (ageInDays < 90) return 18;
    if (ageInDays < 120) return 25;
    return 30;
  }
}

class AnimalAgeHelper {
  static int ageInDays(Animal animal) {
    return DateTime.now().difference(animal.birthDate).inDays;
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.theme});

  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.baby_changing_station,
                    size: 32, color: theme.colorScheme.primary),
                const SizedBox(width: 12),
                Text(
                  'Controle de Peso - Borregos',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Acompanhe o desenvolvimento dos borregos desde o nascimento até 120 dias. Monitore ganho de peso e identifique animais fora do esperado.',
              style: theme.textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.value,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.bodySmall),
                Text(
                  value,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AnimalCell extends StatelessWidget {
  const _AnimalCell({required this.animal});

  final Animal animal;

  @override
  Widget build(BuildContext context) {
    final record = {
      'animal_name': animal.name,
      'animal_code': animal.code,
      'animal_color': animal.nameColor,
    };
    final label = AnimalRecordDisplay.labelFromRecord(record);
    final accent = AnimalRecordDisplay.colorFromDescriptor(animal.nameColor);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: accent,
              ),
        ),
        Text('${animal.breed} • ${animal.gender}'),
      ],
    );
  }
}

class _WeightInputField extends StatelessWidget {
  const _WeightInputField(this.label, this.controller);

  final String label;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        suffixText: 'kg',
      ),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'^[0-9]*[.,]?[0-9]{0,1}')),
      ],
    );
  }
}

enum LambAgeFilter {
  all,
  upTo3Months,
  threeToSixMonths,
  sixToNineMonths,
  nineToTwelveMonths,
}

extension LambAgeFilterLabel on LambAgeFilter {
  String get label {
    switch (this) {
      case LambAgeFilter.upTo3Months:
        return '0-3 meses';
      case LambAgeFilter.threeToSixMonths:
        return '3-6 meses';
      case LambAgeFilter.sixToNineMonths:
        return '6-9 meses';
      case LambAgeFilter.nineToTwelveMonths:
        return '9-12 meses';
      case LambAgeFilter.all:
      default:
        return 'Todas as idades';
    }
  }
}
