import 'local_db.dart';

/// Repository para gerenciar vacinações
class VaccinationRepository {
  final AppDatabase _db;

  VaccinationRepository(this._db);

  /// Retorna todas as vacinações
  Future<List<Map<String, dynamic>>> getAll() async {
    return await _db.db.query(
      'vaccinations',
      orderBy: 'scheduled_date DESC',
    );
  }

  /// Retorna uma vacinação por ID
  Future<Map<String, dynamic>?> getById(String id) async {
    final maps = await _db.db.query(
      'vaccinations',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (maps.isEmpty) return null;
    return maps.first;
  }

  /// Retorna vacinações de um animal específico
  Future<List<Map<String, dynamic>>> getByAnimalId(String animalId) async {
    return await _db.db.query(
      'vaccinations',
      where: 'animal_id = ?',
      whereArgs: [animalId],
      orderBy: 'scheduled_date DESC',
    );
  }

  /// Retorna vacinações agendadas (status = 'Agendada')
  Future<List<Map<String, dynamic>>> getScheduled() async {
    return await _db.db.query(
      'vaccinations',
      where: 'status = ?',
      whereArgs: ['Agendada'],
      orderBy: 'scheduled_date ASC',
    );
  }

  /// Retorna vacinações por status
  Future<List<Map<String, dynamic>>> getByStatus(String status) async {
    return await _db.db.query(
      'vaccinations',
      where: 'status = ?',
      whereArgs: [status],
      orderBy: 'scheduled_date DESC',
    );
  }

  /// Retorna vacinações vencidas (agendadas com data passada)
  Future<List<Map<String, dynamic>>> getOverdue() async {
    return await _db.db.rawQuery('''
      SELECT * FROM vaccinations
      WHERE status = 'Agendada'
      AND date(scheduled_date) < date('now')
      ORDER BY scheduled_date ASC
    ''');
  }

  /// Retorna vacinações próximas (dentro de X dias)
  Future<List<Map<String, dynamic>>> getUpcoming(int daysThreshold) async {
    return await _db.db.rawQuery('''
      SELECT * FROM vaccinations
      WHERE status = 'Agendada'
      AND date(scheduled_date) BETWEEN date('now') AND date('now', '+$daysThreshold days')
      ORDER BY scheduled_date ASC
    ''');
  }

  /// Insere uma nova vacinação
  Future<void> insert(Map<String, dynamic> vaccination) async {
    await _db.db.insert('vaccinations', vaccination);
  }

  /// Atualiza uma vacinação
  Future<void> update(String id, Map<String, dynamic> updates) async {
    await _db.db.update(
      'vaccinations',
      updates,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Deleta uma vacinação
  Future<void> delete(String id) async {
    await _db.db.delete(
      'vaccinations',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// Retorna vacinações com informações do animal (join)
  Future<List<Map<String, dynamic>>> getAllWithAnimalInfo({
    String? species,
    String? category,
    String? searchTerm,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final args = <dynamic>[];
    final filters = _buildFilters(
      args,
      species: species,
      category: category,
      searchTerm: searchTerm,
      startDate: startDate,
      endDate: endDate,
      dateColumn: 'date(v.scheduled_date)',
    );

    final rows = await _db.db.rawQuery('''
      SELECT 
        v.*,
        a.name as animal_name,
        a.code as animal_code,
        a.name_color as animal_color,
        a.species as animal_species,
        a.category as animal_category
      FROM vaccinations v
      LEFT JOIN animals a ON a.id = v.animal_id
      ${filters.isNotEmpty ? 'WHERE ${filters.join(' AND ')}' : ''}
      ORDER BY v.scheduled_date DESC
    ''', args);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> getOverdueWithAnimalInfo({
    String? species,
    String? category,
    String? searchTerm,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final args = <dynamic>[];
    final filters = _buildFilters(
      args,
      species: species,
      category: category,
      searchTerm: searchTerm,
      startDate: startDate,
      endDate: endDate,
      dateColumn: 'date(v.scheduled_date)',
    );
    final whereClause = StringBuffer(
      "v.status = 'Agendada' AND date(v.scheduled_date) < date('now')",
    );
    if (filters.isNotEmpty) {
      whereClause.write(' AND ${filters.join(' AND ')}');
    }

    final rows = await _db.db.rawQuery('''
      SELECT v.*, 
             a.name AS animal_name, 
             a.code AS animal_code, 
             a.name_color AS animal_color,
             a.species AS animal_species,
             a.category AS animal_category
      FROM vaccinations v
      LEFT JOIN animals a ON a.id = v.animal_id
      WHERE ${whereClause.toString()}
      ORDER BY v.scheduled_date ASC
    ''', args);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> getScheduledWithAnimalInfo({
    String? species,
    String? category,
    String? searchTerm,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final args = <dynamic>[];
    final filters = _buildFilters(
      args,
      species: species,
      category: category,
      searchTerm: searchTerm,
      startDate: startDate,
      endDate: endDate,
      dateColumn: 'date(v.scheduled_date)',
    );
    final whereClause = StringBuffer(
      "v.status = 'Agendada' AND date(v.scheduled_date) >= date('now')",
    );
    if (filters.isNotEmpty) {
      whereClause.write(' AND ${filters.join(' AND ')}');
    }

    final rows = await _db.db.rawQuery('''
      SELECT v.*, 
             a.name AS animal_name, 
             a.code AS animal_code, 
             a.name_color AS animal_color,
             a.species AS animal_species,
             a.category AS animal_category
      FROM vaccinations v
      LEFT JOIN animals a ON a.id = v.animal_id
      WHERE ${whereClause.toString()}
      ORDER BY v.scheduled_date ASC
    ''', args);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> getAppliedWithAnimalInfo({
    String? species,
    String? category,
    String? searchTerm,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final args = <dynamic>[];
    final filters = _buildFilters(
      args,
      species: species,
      category: category,
      searchTerm: searchTerm,
      startDate: startDate,
      endDate: endDate,
      dateColumn: "date(COALESCE(v.applied_date, v.scheduled_date))",
    );
    final whereClause = StringBuffer("v.status = 'Aplicada'");
    if (filters.isNotEmpty) {
      whereClause.write(' AND ${filters.join(' AND ')}');
    }

    final rows = await _db.db.rawQuery('''
      SELECT v.*, 
             a.name AS animal_name, 
             a.code AS animal_code, 
             a.name_color AS animal_color,
             a.species AS animal_species,
             a.category AS animal_category
      FROM vaccinations v
      LEFT JOIN animals a ON a.id = v.animal_id
      WHERE ${whereClause.toString()}
      ORDER BY date(COALESCE(v.applied_date, v.scheduled_date)) DESC
    ''', args);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> getCancelledWithAnimalInfo({
    String? species,
    String? category,
    String? searchTerm,
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final args = <dynamic>[];
    final filters = _buildFilters(
      args,
      species: species,
      category: category,
      searchTerm: searchTerm,
      startDate: startDate,
      endDate: endDate,
      dateColumn: 'date(v.scheduled_date)',
    );
    final whereClause = StringBuffer("v.status = 'Cancelada'");
    if (filters.isNotEmpty) {
      whereClause.write(' AND ${filters.join(' AND ')}');
    }

    final rows = await _db.db.rawQuery('''
      SELECT v.*, 
             a.name AS animal_name, 
             a.code AS animal_code, 
             a.name_color AS animal_color,
             a.species AS animal_species,
             a.category AS animal_category
      FROM vaccinations v
      LEFT JOIN animals a ON a.id = v.animal_id
      WHERE ${whereClause.toString()}
      ORDER BY date(v.scheduled_date) DESC
    ''', args);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> getPendingAlertsWithin(
      DateTime horizon) async {
    final limit = horizon.toIso8601String().split('T').first;
    return await _db.db.rawQuery('''
      SELECT 
        v.*, 
        a.name AS animal_name, 
        a.code AS animal_code, 
        a.name_color AS animal_color
      FROM vaccinations v
      LEFT JOIN animals a ON a.id = v.animal_id
      WHERE v.status NOT IN ('Aplicada', 'Cancelada')
        AND date(v.scheduled_date) <= date(?)
      ORDER BY v.scheduled_date ASC
    ''', [limit]);
  }

  List<String> _buildFilters(
    List<dynamic> args, {
    String? species,
    String? category,
    String? searchTerm,
    DateTime? startDate,
    DateTime? endDate,
    required String dateColumn,
  }) {
    final filters = <String>[];

    if (species != null && species.isNotEmpty) {
      filters.add(
        "LOWER(COALESCE(v.species, a.species, '')) = ?",
      );
      args.add(species.toLowerCase());
    }

    if (category != null && category.isNotEmpty) {
      filters.add(
        "LOWER(COALESCE(v.category, a.category, '')) = ?",
      );
      args.add(category.toLowerCase());
    }

    if (searchTerm != null && searchTerm.trim().isNotEmpty) {
      final like = '%${searchTerm.trim().toLowerCase()}%';
      filters.add(
        '('
        "LOWER(COALESCE(a.name, '')) LIKE ? OR "
        "LOWER(COALESCE(a.code, '')) LIKE ? OR "
        "LOWER(COALESCE(v.vaccine_name, '')) LIKE ? OR "
        "LOWER(COALESCE(v.notes, '')) LIKE ?"
        ')',
      );
      args.addAll([like, like, like, like]);
    }

    if (startDate != null) {
      filters.add('$dateColumn >= date(?)');
      args.add(startDate.toIso8601String().split('T').first);
    }

    if (endDate != null) {
      filters.add('$dateColumn <= date(?)');
      args.add(endDate.toIso8601String().split('T').first);
    }

    return filters;
  }
}
