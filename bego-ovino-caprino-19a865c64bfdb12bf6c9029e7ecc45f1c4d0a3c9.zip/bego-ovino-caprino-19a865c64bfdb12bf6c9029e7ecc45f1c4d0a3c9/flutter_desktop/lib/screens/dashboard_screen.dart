  
  void _handleQuickAction(BuildContext context, String action) {
    switch (action) {
      case 'Agendar Vacinação':
        showDialog(
          context: context,
          builder: (context) => const VaccinationFormDialog(),
        );
        break;
      case 'Nova Cobertura':
        showDialog(
          context: context,
          builder: (context) => const BreedingFormDialog(),
        );
        break;
      case 'Nova Anotação':
        showDialog(
          context: context,
          builder: (context) => const NotesFormDialog(),
        );
        break;
      case 'Lançamento Financeiro':
        showDialog(
          context: context,
          builder: (context) => const FinancialFormDialog(),
        );
        break;
      case 'Busca Avançada':
        showDialog(
          context: context,
          builder: (context) => const AdvancedSearchDialog(),
        );
        break;
      case 'Relatório Mensal':
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => const ReportsScreen()),
        );
        break;
    }
  }

}