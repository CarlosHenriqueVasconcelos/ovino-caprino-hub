import { CompleteDashboard } from "@/components/CompleteDashboard";

const Index = () => {
  return <CompleteDashboard />;
};

export default Index;
